# Java REST API

API RESTful usando Java, Spring Boot e PostgreSQL.

## Como executar

```bash
./mvnw spring-boot:run
```

A API roda em: `http://localhost:8080`

## Endpoints principais

- `GET /users`
- `POST /users`
- `PUT /users/{id}`
- `DELETE /users/{id}`

## Testes

```bash
./mvnw test
```

## CI/CD

Pipeline automatizado via GitHub Actions: build + test.

---

Feito com ❤️ em Java.
